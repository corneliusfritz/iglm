# iglm <img src="man/figures/logo.png" align="right" height="120" alt="" />

