library(testthat)
library(iglm)

test_check("iglm")
